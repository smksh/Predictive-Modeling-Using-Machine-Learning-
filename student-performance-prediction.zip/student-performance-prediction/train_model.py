"""
Student Performance Prediction
Predict a student's writing score using available demographic/context features
and math/reading scores. This is an educational demonstration, not a high-stakes
student assessment tool.
"""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "data" / "StudentsPerformance.csv"
OUT_PATH = ROOT / "visualizations"
OUT_PATH.mkdir(exist_ok=True)

df = pd.read_csv(DATA_PATH)
target = "writing score"
X = df.drop(columns=[target])
y = df[target]

categorical = X.select_dtypes(include="object").columns.tolist()
numeric = X.select_dtypes(exclude="object").columns.tolist()

preprocess = ColumnTransformer(
    transformers=[
        ("categorical", OneHotEncoder(handle_unknown="ignore"), categorical),
        ("numeric", "passthrough", numeric),
    ]
)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42
)

models = {
    "Linear Regression": LinearRegression(),
    "Random Forest": RandomForestRegressor(
        n_estimators=300, random_state=42, min_samples_leaf=2
    ),
}

results = []
predictions = {}
for name, estimator in models.items():
    model = Pipeline([("preprocess", preprocess), ("model", estimator)])
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    predictions[name] = pred
    results.append({
        "Model": name,
        "MAE": mean_absolute_error(y_test, pred),
        "RMSE": mean_squared_error(y_test, pred) ** 0.5,
        "R2": r2_score(y_test, pred),
    })

results_df = pd.DataFrame(results).sort_values("RMSE")
print("Dataset shape:", df.shape)
print("\nMissing values:\n", df.isna().sum())
print("\nModel evaluation (lower MAE/RMSE and higher R² are better):")
print(results_df.round(3).to_string(index=False))

# Plot actual vs predicted for the best model by RMSE
best_name = results_df.iloc[0]["Model"]
best_pred = predictions[best_name]
plt.figure(figsize=(7, 5))
sns.scatterplot(x=y_test, y=best_pred, alpha=0.7)
plt.plot([0, 100], [0, 100], linestyle="--")
plt.xlabel("Actual writing score")
plt.ylabel("Predicted writing score")
plt.title(f"Actual vs Predicted Writing Scores — {best_name}")
plt.tight_layout()
plt.savefig(OUT_PATH / "actual_vs_predicted.png", dpi=160)
plt.close()

# Compare model metrics
metrics_long = results_df.melt(
    id_vars="Model", value_vars=["MAE", "RMSE"], var_name="Metric", value_name="Value"
)
plt.figure(figsize=(8, 5))
sns.barplot(data=metrics_long, x="Metric", y="Value", hue="Model")
plt.title("Regression Error Comparison")
plt.tight_layout()
plt.savefig(OUT_PATH / "model_error_comparison.png", dpi=160)
plt.close()

print(f"\nCharts saved to: {OUT_PATH}")
print("\nNote: This is a practice model. Do not use predictions to make decisions about real students.")
