# Student Performance Prediction using Machine Learning 📊🤖

A supervised machine-learning project that predicts a student's **writing score** using the `StudentsPerformance.csv` dataset. It compares Linear Regression and Random Forest Regression, evaluates their predictions on a held-out test set, and saves visualizations of model performance.

## Dataset

The dataset contains **1,000 records and 8 columns**:

- Categorical features: gender, race/ethnicity, parental level of education, lunch, test preparation course
- Numeric features: math score, reading score
- Target: writing score

The provided dataset has no missing values. The project still checks for missing values as part of its initial inspection.

## Project Goals

- Load and inspect a real tabular dataset.
- Separate input features from the target variable.
- Encode categorical variables using one-hot encoding.
- Split data into training and test sets.
- Train and compare two regression algorithms.
- Evaluate results using MAE, RMSE, and R².
- Visualize actual versus predicted scores and compare model errors.

## Models

1. **Linear Regression** — a simple baseline model.
2. **Random Forest Regressor** — an ensemble model that can learn nonlinear patterns.

The model with the lower test RMSE is reported as the best-performing model for this particular split. Results can vary with the dataset and split; do not claim a specific performance score until you run the code.

## Evaluation Metrics

- **MAE:** average absolute prediction error; lower is better.
- **RMSE:** gives larger errors more weight; lower is better.
- **R²:** compares the model with a baseline that predicts the target mean; closer to 1 is generally better.

## Tech Stack

Python · Pandas · Scikit-learn · Matplotlib · Seaborn

## Repository Structure

```text
student-performance-prediction/
├── data/
│   └── StudentsPerformance.csv
├── notebooks/
│   └── model_training.ipynb
├── visualizations/
├── train_model.py
├── requirements.txt
└── README.md
```

## Setup and Run

Use Python 3.10+.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python train_model.py
```

On Windows, activate the environment with:

```powershell
.venv\Scripts\activate
```

The script prints evaluation metrics and saves charts in the `visualizations/` folder.

## Run the Notebook

```bash
jupyter notebook notebooks/model_training.ipynb
```

Run all cells from top to bottom.

## Responsible Use

This is an educational exercise. Student scores are influenced by many factors not represented in this dataset. Predictions may be inaccurate or reflect biases in the data. Do not use this model for grading, admissions, discipline, or other high-stakes decisions about students.

## Future Improvements

- Add cross-validation and hyperparameter tuning.
- Compare more regression algorithms.
- Analyze residuals and possible subgroup performance differences carefully.
- Add a model-prediction form or small demo interface.
- Track experiments and document results after each run.

---

Created as a practice project for supervised learning and model evaluation.
